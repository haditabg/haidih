# Tepthon-heroku
[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Ftgcatub%2Fnekopack&count_bg=%2379C83D&title_bg=%23555555&icon=&icon_color=%23E7E7E7&title=hits&edge_flat=false)](https://github.com/Tepthonee/Deploy)

This repo is only for deploying purpose if you want to look into main source code head to [main source](https://github.com/Tepthonee/PPF22) 

## Deploy

To be safe fork this repo and then press deploy button from the forked repo 

Fork Deploy is highly recommended

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)

## credits
   - [@Tepthon](https://t.me/Tepthon)
   - [@Mohammad](https://t.me/PPF22)
- شكرًا لك @zzzzl1l .
